package com.signify.StudentResultPublisher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentResultPublisherApplicationTests {

	@Test
	void contextLoads() {
	}

}
