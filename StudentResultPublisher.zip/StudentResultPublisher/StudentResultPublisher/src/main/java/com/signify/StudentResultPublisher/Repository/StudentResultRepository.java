package com.signify.StudentResultPublisher.Repository;

import com.signify.StudentResultPublisher.Models.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentResultRepository extends JpaRepository<Student, Long> {
}
