package com.signify.StudentResultPublisher.Controller;

import com.signify.StudentResultPublisher.Repository.StudentResultRepository;
import com.signify.StudentResultPublisher.Models.Student;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class StudentResultController {
    @Autowired
    private StudentResultRepository studentRepository;

    @Transactional
    @PostMapping("/studentEntry")
    public ResponseEntity<Map<String, String>> studentEntry(@RequestBody Student student) {

        calculateGrades(student);

        Student savedStudent = studentRepository.save(student);

        Map<String, String> response = new HashMap<>();
        response.put("Status", "Student Added");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/viewStudents")
    public ResponseEntity<List<Student>> studentList() {
        List<Student> students = studentRepository.findAll();
        return ResponseEntity.ok(students);
    }

    private void calculateGrades(Student student) {
        // Calculating grade based on Marks
        String[] subjects = {"Maths", "Physics", "Chemistry", "English", "Social", "Computer"};
        int[] marks = {student.getMathsMarks(), student.getPhysicsMarks(), student.getChemistryMarks(),
                student.getEnglishMarks(), student.getSocialMarks(), student.getComputerMarks()};
        String[] grades = new String[6];
        boolean passed = true;

        for (int i = 0; i < 6; i++) {
            grades[i] = getGrade(marks[i]);
            if (grades[i].equals("F")) {
                passed = false;
            }
        }

        student.setMathsGrade(grades[0]);
        student.setPhysicsGrade(grades[1]);
        student.setChemistryGrade(grades[2]);
        student.setEnglishGrade(grades[3]);
        student.setSocialGrade(grades[4]);
        student.setComputerGrade(grades[5]);
        student.setQualificationStatus(passed ? "Passed" : "Failed");
    }

    private String getGrade(int marks) {
        if (marks >= 90) return "S";
        if (marks >= 85) return "A+";
        if (marks >= 80) return "A";
        if (marks >= 75) return "B+";
        if (marks >= 70) return "B";
        if (marks >= 65) return "C+";
        if (marks >= 60) return "C";
        if (marks >= 55) return "D+";
        if (marks >= 50) return "D";
        return "F";
    }
}
