package com.signify.StudentResultPublisher.Models;

import jakarta.persistence.*;

@Entity
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String rollNumber;
    private String department;

    private int mathsMarks;
    private int physicsMarks;
    private int chemistryMarks;
    private int englishMarks;
    private int socialMarks;
    private int computerMarks;

    private String mathsGrade;
    private String physicsGrade;
    private String chemistryGrade;
    private String englishGrade;
    private String socialGrade;
    private String computerGrade;

    private String qualificationStatus;

    public Student() {
    }

    public Student(String name, String rollNumber, String department, int mathsMarks, int physicsMarks, int chemistryMarks, int englishMarks, int socialMarks, int computerMarks) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.department = department;
        this.mathsMarks = mathsMarks;
        this.physicsMarks = physicsMarks;
        this.chemistryMarks = chemistryMarks;
        this.englishMarks = englishMarks;
        this.socialMarks = socialMarks;
        this.computerMarks = computerMarks;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getMathsMarks() {
        return mathsMarks;
    }

    public void setMathsMarks(int mathsMarks) {
        this.mathsMarks = mathsMarks;
    }

    public int getPhysicsMarks() {
        return physicsMarks;
    }

    public void setPhysicsMarks(int physicsMarks) {
        this.physicsMarks = physicsMarks;
    }

    public int getChemistryMarks() {
        return chemistryMarks;
    }

    public void setChemistryMarks(int chemistryMarks) {
        this.chemistryMarks = chemistryMarks;
    }

    public int getEnglishMarks() {
        return englishMarks;
    }

    public void setEnglishMarks(int englishMarks) {
        this.englishMarks = englishMarks;
    }

    public int getSocialMarks() {
        return socialMarks;
    }

    public void setSocialMarks(int socialMarks) {
        this.socialMarks = socialMarks;
    }

    public int getComputerMarks() {
        return computerMarks;
    }

    public void setComputerMarks(int computerMarks) {
        this.computerMarks = computerMarks;
    }

    public String getMathsGrade() {
        return mathsGrade;
    }

    public void setMathsGrade(String mathsGrade) {
        this.mathsGrade = mathsGrade;
    }

    public String getPhysicsGrade() {
        return physicsGrade;
    }

    public void setPhysicsGrade(String physicsGrade) {
        this.physicsGrade = physicsGrade;
    }

    public String getChemistryGrade() {
        return chemistryGrade;
    }

    public void setChemistryGrade(String chemistryGrade) {
        this.chemistryGrade = chemistryGrade;
    }

    public String getEnglishGrade() {
        return englishGrade;
    }

    public void setEnglishGrade(String englishGrade) {
        this.englishGrade = englishGrade;
    }

    public String getSocialGrade() {
        return socialGrade;
    }

    public void setSocialGrade(String socialGrade) {
        this.socialGrade = socialGrade;
    }

    public String getComputerGrade() {
        return computerGrade;
    }

    public void setComputerGrade(String computerGrade) {
        this.computerGrade = computerGrade;
    }

    public String getQualificationStatus() {
        return qualificationStatus;
    }

    public void setQualificationStatus(String qualificationStatus) {
        this.qualificationStatus = qualificationStatus;
    }
}
