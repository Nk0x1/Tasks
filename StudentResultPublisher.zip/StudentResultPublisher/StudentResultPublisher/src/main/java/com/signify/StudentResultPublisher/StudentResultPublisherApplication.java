package com.signify.StudentResultPublisher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentResultPublisherApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentResultPublisherApplication.class, args);
	}

}
