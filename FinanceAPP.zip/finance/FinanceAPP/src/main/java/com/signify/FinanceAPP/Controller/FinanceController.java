package com.signify.FinanceAPP.Controller;

import com.signify.FinanceAPP.Models.Finance;
import com.signify.FinanceAPP.Repository.FinanceRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FinanceController {

    @Autowired
    private FinanceRepository financeRepository;

    // Create a new transaction
    @Transactional
    @PostMapping("/addTransaction")
    public ResponseEntity<Map<String, String>> addTransaction(@RequestBody Finance finance) {
        // Correctly using the financeRepository to save the transaction
        Finance savedTransaction = financeRepository.save(finance);

        Map<String, String> response = new HashMap<>();
        response.put("Status", "Transaction Added");
        return ResponseEntity.ok(response);
    }

    // Retrieve all expenses
    @GetMapping("/viewAllExpenses")
    public ResponseEntity<List<Finance>> viewExpenses() {
        List<Finance> expenses = financeRepository.findAll();
        return ResponseEntity.ok(expenses);
    }
}
