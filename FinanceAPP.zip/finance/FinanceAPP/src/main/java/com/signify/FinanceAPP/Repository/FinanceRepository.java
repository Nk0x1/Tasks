package com.signify.FinanceAPP.Repository;

import com.signify.FinanceAPP.Models.Finance;
import org.springframework.data.jpa.repository.JpaRepository;


public interface FinanceRepository extends JpaRepository<Finance, Long> {
}
