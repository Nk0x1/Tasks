package com.signify.Bookstore.Controller;

import com.signify.Bookstore.Repository.BookstoreRepository;
import com.signify.Bookstore.Models.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class BookstoreController {

    @Autowired
    private BookstoreRepository bookRepository;

    @PostMapping("/addBooks")
    public ResponseEntity<Map<String, String>> addBook(@RequestBody Book book) {
        bookRepository.save(book);
        Map<String, String> response = new HashMap<>();
        response.put("Status", "Book Added");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/viewAllBooks")
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> book = bookRepository.findAll();
        return ResponseEntity.ok(book);
    }
}
