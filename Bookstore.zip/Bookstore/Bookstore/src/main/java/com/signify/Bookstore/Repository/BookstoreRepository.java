package com.signify.Bookstore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.signify.Bookstore.Models.Book;

public interface BookstoreRepository extends JpaRepository<Book, Long> {
}
