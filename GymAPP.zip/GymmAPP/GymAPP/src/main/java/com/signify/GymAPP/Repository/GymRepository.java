package com.signify.GymAPP.Repository;

import com.signify.GymAPP.Models.Gym;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GymRepository extends JpaRepository<Gym, Long> {
}
