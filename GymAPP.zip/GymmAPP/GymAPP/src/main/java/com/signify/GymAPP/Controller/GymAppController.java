package com.signify.GymAPP.Controller;


import com.signify.GymAPP.Models.Gym;
import com.signify.GymAPP.Repository.GymRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class GymAppController {
    @Autowired
    private GymRepository gymRepo;

    @Transactional
    @PostMapping("/addMembers")
    public ResponseEntity<Map<String, String>> MemberEntry(@RequestBody Gym gym){
        Gym gymob = gymRepo.save(gym);
        Map<String, String> response = new HashMap<>();
        response.put("Status", "Member Added");
        return ResponseEntity.ok(response);
    }

    @GetMapping("/viewAllMembers")
    public ResponseEntity<List<Gym>> MemberList(){
        List<Gym> member = gymRepo.findAll();
        return ResponseEntity.ok(member);
    }

}
